package app.retrobox

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.IOException

/**
 * Runs one game. The emulator itself (EmulatorJS) runs inside a WebView. The
 * ROM and optional BIOS are served to it from a fake https host, so the files
 * are streamed straight from the phone's storage and never uploaded anywhere.
 */
class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_NAME = "name"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SYSTEM = "system"
        const val EXTRA_BIOS_URI = "bios_uri"
        const val EXTRA_BIOS_NAME = "bios_name"
        private const val HOST = "app.local"
    }

    private lateinit var web: WebView
    private var romUri: Uri? = null
    private var biosUri: Uri? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val uriString = intent.getStringExtra(EXTRA_URI)
        val system = intent.getStringExtra(EXTRA_SYSTEM)
        if (uriString == null || system == null) {
            finish()
            return
        }
        val fileName = intent.getStringExtra(EXTRA_NAME) ?: "game"
        val title = intent.getStringExtra(EXTRA_TITLE) ?: fileName
        romUri = Uri.parse(uriString)
        biosUri = intent.getStringExtra(EXTRA_BIOS_URI)?.let { Uri.parse(it) }

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        val settings = web.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url
                if (url.host != HOST) return null
                val path = url.path ?: "/"
                try {
                    if (path == "/player.html") {
                        return WebResourceResponse("text/html", "utf-8", assets.open("player.html"))
                    }
                    if (path.startsWith("/rom/")) return streamOf(romUri)
                    if (path.startsWith("/bios/")) return streamOf(biosUri)
                } catch (e: Exception) {
                    // Fall through to a 404 below.
                }
                return WebResourceResponse(
                    "text/plain", "utf-8", 404, "Not Found",
                    emptyMap(), ByteArrayInputStream(ByteArray(0))
                )
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // Keep the player on its own page.
                return request.url.host != HOST
            }
        }

        val builder = Uri.Builder()
            .scheme("https")
            .authority(HOST)
            .path("/player.html")
            .appendQueryParameter("core", system)
            .appendQueryParameter("name", fileName)
            .appendQueryParameter("title", title)
        if (biosUri != null) {
            builder.appendQueryParameter("bios", "1")
            builder.appendQueryParameter("biosName", intent.getStringExtra(EXTRA_BIOS_NAME) ?: "bios.bin")
        }
        web.loadUrl(builder.build().toString())
        hideSystemBars()
    }

    private fun streamOf(uri: Uri?): WebResourceResponse {
        if (uri == null) throw IOException("No file")
        val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
        val headers = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Cache-Control" to "no-store"
        )
        return WebResourceResponse("application/octet-stream", null, 200, "OK", headers, input)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("Leave game?")
            .setMessage("Progress that was not saved in the emulator menu will be lost.")
            .setPositiveButton("Leave") { _, _ -> finish() }
            .setNegativeButton("Keep playing", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        if (::web.isInitialized) {
            web.onPause()
            web.pauseTimers()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }
}
