package app.retrobox

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_ADD_FILES = 1
        const val REQ_ADD_FOLDER = 2
        const val REQ_PICK_BIOS = 3
        const val BG = 0xFF0F1115.toInt()
        const val CARD = 0xFF1A1D25.toInt()
        const val ACCENT = 0xFF7C5CFF.toInt()
        const val TEXT = 0xFFE8EAF0.toInt()
        const val MUTED = 0xFF8B90A0.toInt()
    }

    private sealed class Row {
        data class Header(val text: String) : Row()
        data class Item(val game: Game) : Row()
    }

    private lateinit var library: Library
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var adapter: RowAdapter
    private var rows: List<Row> = emptyList()
    private var pendingBiosSystem: String? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(16), dp(36), dp(16), dp(8))

        val title = TextView(this)
        title.text = "RetroBox"
        title.setTextColor(TEXT)
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        val sub = TextView(this)
        sub.text = "NES, SNES, Game Boy, GBA, N64, Genesis, PlayStation and more"
        sub.setTextColor(MUTED)
        sub.textSize = 13f
        sub.setPadding(0, dp(2), 0, dp(12))
        root.addView(sub)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.addView(makeButton("Add games") { pickFiles() }, buttonParams())
        buttons.addView(makeButton("Add folder") { pickFolder() }, buttonParams())
        buttons.addView(makeButton("BIOS") { chooseBiosSystem() }, buttonParams())
        root.addView(buttons)

        val frame = LinearLayout(this)
        frame.orientation = LinearLayout.VERTICAL
        frame.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        )

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.setBackgroundColor(BG)
        list.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        adapter = RowAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            val row = rows[position]
            if (row is Row.Item) play(row.game)
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val row = rows[position]
            if (row is Row.Item) showGameMenu(row.game)
            true
        }

        empty = TextView(this)
        empty.text = "No games yet.\n\nTap \"Add games\" and choose ROM files you own, or \"Add folder\" to import a whole folder."
        empty.setTextColor(MUTED)
        empty.textSize = 15f
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(24), dp(48), dp(24), dp(24))

        frame.addView(empty)
        frame.addView(list)
        root.addView(frame)
        setContentView(root)
    }

    private fun buttonParams(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.setMargins(dp(3), 0, dp(3), dp(8))
        return p
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(ACCENT)
        b.setOnClickListener { action() }
        return b
    }

    // ---------------------------------------------------------------- list

    private fun refresh() {
        val games = library.games()
        val built = ArrayList<Row>()
        val grouped = games.groupBy { it.system }
        for (system in Systems.all) {
            val inSystem = grouped[system.id] ?: continue
            built.add(Row.Header("${system.label}  (${inSystem.size})"))
            for (g in inSystem.sortedBy { it.title.lowercase() }) built.add(Row.Item(g))
        }
        // Games whose system id is no longer known.
        for ((id, inSystem) in grouped) {
            if (Systems.get(id) != null) continue
            built.add(Row.Header(id))
            for (g in inSystem) built.add(Row.Item(g))
        }
        rows = built
        adapter.notifyDataSetChanged()
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        list.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Header) 0 else 1
        override fun isEnabled(position: Int) = rows[position] is Row.Item

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tv = (convertView as? TextView) ?: TextView(this@MainActivity)
            when (val row = rows[position]) {
                is Row.Header -> {
                    tv.text = row.text
                    tv.setTextColor(ACCENT)
                    tv.textSize = 13f
                    tv.typeface = Typeface.DEFAULT_BOLD
                    tv.setBackgroundColor(BG)
                    tv.setPadding(dp(4), dp(18), dp(4), dp(6))
                }
                is Row.Item -> {
                    tv.text = row.game.title
                    tv.setTextColor(TEXT)
                    tv.textSize = 16f
                    tv.typeface = Typeface.DEFAULT
                    tv.setBackgroundColor(CARD)
                    tv.setPadding(dp(16), dp(14), dp(16), dp(14))
                    tv.maxLines = 2
                    val lp = ViewGroup.MarginLayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    tv.layoutParams = lp
                }
            }
            return tv
        }
    }

    // ------------------------------------------------------------- playing

    private fun play(game: Game) {
        val bios = library.bios().firstOrNull { it.system == game.system }
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra(PlayerActivity.EXTRA_URI, game.uri)
        intent.putExtra(PlayerActivity.EXTRA_NAME, game.name)
        intent.putExtra(PlayerActivity.EXTRA_TITLE, game.title)
        intent.putExtra(PlayerActivity.EXTRA_SYSTEM, game.system)
        if (bios != null) {
            intent.putExtra(PlayerActivity.EXTRA_BIOS_URI, bios.uri)
            intent.putExtra(PlayerActivity.EXTRA_BIOS_NAME, bios.name)
        }
        startActivity(intent)
    }

    private fun showGameMenu(game: Game) {
        val options = arrayOf("Play", "Change system", "Remove from library")
        AlertDialog.Builder(this)
            .setTitle(game.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> play(game)
                    1 -> chooseSystem("System for ${game.title}", Systems.all) { sys ->
                        library.updateSystem(game.uri, sys.id)
                        refresh()
                    }
                    2 -> {
                        library.remove(game.uri)
                        refresh()
                    }
                }
            }
            .show()
    }

    // ---------------------------------------------------------- adding ROMs

    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(intent, REQ_ADD_FILES)
    }

    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(intent, REQ_ADD_FOLDER)
    }

    private fun chooseBiosSystem() {
        val needsBios = Systems.all.filter {
            it.id in listOf(
                "psx", "segaCD", "segaSaturn", "3do", "nds", "pce",
                "atari5200", "atari7800", "lynx", "jaguar", "arcade", "gba", "segaMD", "coleco"
            )
        }
        chooseSystem("BIOS for which system?", needsBios) { sys ->
            pendingBiosSystem = sys.id
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type = "*/*"
            intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
            startActivityForResult(intent, REQ_PICK_BIOS)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_ADD_FILES -> {
                val uris = ArrayList<Uri>()
                data.data?.let { uris.add(it) }
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                }
                val found = ArrayList<Pair<Uri, String>>()
                for (uri in uris) {
                    keepAccess(uri)
                    found.add(uri to (displayName(uri) ?: "game"))
                }
                importFiles(found)
            }
            REQ_ADD_FOLDER -> {
                val tree = data.data ?: return
                keepAccess(tree)
                Toast.makeText(this, "Scanning folder…", Toast.LENGTH_SHORT).show()
                Thread {
                    val found = ArrayList<Pair<Uri, String>>()
                    try {
                        scanTree(tree, DocumentsContract.getTreeDocumentId(tree), found, 0)
                    } catch (e: Exception) {
                        // Use whatever was found before the error.
                    }
                    runOnUiThread { importFiles(found) }
                }.start()
            }
            REQ_PICK_BIOS -> {
                val uri = data.data ?: return
                val system = pendingBiosSystem ?: return
                keepAccess(uri)
                val name = displayName(uri) ?: "bios.bin"
                library.setBios(BiosFile(uri.toString(), name, system))
                Toast.makeText(this, "BIOS saved for ${Systems.label(system)}: $name", Toast.LENGTH_LONG)
                    .show()
            }
        }
    }

    private fun keepAccess(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Some providers do not allow persisting; the file then works until restart.
        }
    }

    private fun displayName(uri: Uri): String? {
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0)
        } catch (e: Exception) {
            // Ignore.
        } finally {
            cursor?.close()
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun scanTree(
        tree: Uri,
        parentId: String,
        out: MutableList<Pair<Uri, String>>,
        depth: Int
    ) {
        if (depth > 6) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val cursor = contentResolver.query(children, projection, null, null, null) ?: return
        cursor.use {
            while (it.moveToNext()) {
                val id = it.getString(0)
                val name = it.getString(1) ?: continue
                val mime = it.getString(2)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    scanTree(tree, id, out, depth + 1)
                } else if (Systems.isRomExtension(name)) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id) to name)
                }
            }
        }
    }

    /** Adds files whose system is clear, and asks once about the rest. */
    private fun importFiles(files: List<Pair<Uri, String>>) {
        if (files.isEmpty()) {
            Toast.makeText(this, "No game files found", Toast.LENGTH_SHORT).show()
            return
        }
        val clear = ArrayList<Game>()
        val unclear = ArrayList<Pair<Uri, String>>()
        for ((uri, name) in files) {
            val options = Systems.candidates(name)
            if (options.size == 1) {
                clear.add(Game(uri.toString(), name, options[0].id))
            } else {
                unclear.add(uri to name)
            }
        }
        library.addAll(clear)
        refresh()

        if (unclear.isEmpty()) {
            Toast.makeText(this, "Added ${clear.size} game(s)", Toast.LENGTH_SHORT).show()
            return
        }
        // Offer only the systems that fit the first unclear file's extension.
        val choices = Systems.candidates(unclear[0].second)
        chooseSystem(
            "${unclear.size} file(s) need a system, e.g. ${unclear[0].second}",
            choices
        ) { sys ->
            library.addAll(unclear.map { (uri, name) -> Game(uri.toString(), name, sys.id) })
            refresh()
            Toast.makeText(this, "Added ${clear.size + unclear.size} game(s)", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun chooseSystem(title: String, choices: List<RetroSystem>, onChosen: (RetroSystem) -> Unit) {
        val labels = choices.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which -> onChosen(choices[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
