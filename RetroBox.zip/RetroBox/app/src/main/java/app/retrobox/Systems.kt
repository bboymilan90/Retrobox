package app.retrobox

/** One emulated system. [id] is the EmulatorJS system/core id. */
data class RetroSystem(val id: String, val label: String, val exts: List<String>)

object Systems {

    val all: List<RetroSystem> = listOf(
        RetroSystem("nes", "Nintendo NES / Famicom", listOf("nes", "fds", "unf", "unif")),
        RetroSystem("snes", "Super Nintendo (SNES)", listOf("sfc", "smc", "fig", "swc")),
        RetroSystem("gb", "Game Boy / Game Boy Color", listOf("gb", "gbc")),
        RetroSystem("gba", "Game Boy Advance", listOf("gba")),
        RetroSystem("n64", "Nintendo 64", listOf("n64", "z64", "v64")),
        RetroSystem("nds", "Nintendo DS", listOf("nds")),
        RetroSystem("vb", "Virtual Boy", listOf("vb", "vboy")),
        RetroSystem("segaMS", "Sega Master System", listOf("sms")),
        RetroSystem("segaMD", "Sega Genesis / Mega Drive", listOf("md", "gen", "smd")),
        RetroSystem("segaGG", "Sega Game Gear", listOf("gg")),
        RetroSystem("sega32x", "Sega 32X", listOf("32x")),
        RetroSystem("segaCD", "Sega CD / Mega CD", emptyList()),
        RetroSystem("segaSaturn", "Sega Saturn", emptyList()),
        RetroSystem("psx", "Sony PlayStation", listOf("pbp")),
        RetroSystem("pce", "PC Engine / TurboGrafx-16", listOf("pce")),
        RetroSystem("ngp", "Neo Geo Pocket", listOf("ngp", "ngc")),
        RetroSystem("ws", "WonderSwan", listOf("ws", "wsc")),
        RetroSystem("atari2600", "Atari 2600", listOf("a26")),
        RetroSystem("atari7800", "Atari 7800", listOf("a78")),
        RetroSystem("lynx", "Atari Lynx", listOf("lnx")),
        RetroSystem("jaguar", "Atari Jaguar", listOf("j64", "jag")),
        RetroSystem("3do", "3DO", emptyList()),
        RetroSystem("coleco", "ColecoVision", listOf("col")),
        RetroSystem("arcade", "Arcade (MAME / Neo Geo)", emptyList())
    )

    private val byId: Map<String, RetroSystem> = all.associateBy { it.id }

    fun get(id: String): RetroSystem? = byId[id]

    fun label(id: String): String = byId[id]?.label ?: id

    private val discSystems = listOf("psx", "segaCD", "segaSaturn", "3do")

    /** Extensions that do not point to a single system. */
    private val ambiguous: Map<String, List<String>> = mapOf(
        "bin" to listOf("segaMD", "atari2600", "atari7800", "psx", "segaCD", "segaSaturn"),
        "iso" to discSystems,
        "img" to discSystems,
        "chd" to discSystems,
        "zip" to (listOf("arcade") + all.map { it.id }.filter { it != "arcade" }),
        "7z" to (listOf("arcade") + all.map { it.id }.filter { it != "arcade" })
    )

    private val knownExts: Set<String> =
        all.flatMap { it.exts }.toSet() + setOf("bin", "iso", "chd", "img", "zip", "7z")

    fun extensionOf(fileName: String): String = fileName.substringAfterLast('.', "").lowercase()

    /** True for files worth importing when scanning a folder. */
    fun isRomExtension(fileName: String): Boolean = extensionOf(fileName) in knownExts

    /**
     * Systems a file could belong to. A single result means the system was
     * identified from the extension; several results mean the user must choose.
     */
    fun candidates(fileName: String): List<RetroSystem> {
        val ext = extensionOf(fileName)
        val exact = all.filter { ext in it.exts }
        if (exact.isNotEmpty()) return exact
        val ids = ambiguous[ext] ?: all.map { it.id }
        return ids.mapNotNull { byId[it] }
    }
}
