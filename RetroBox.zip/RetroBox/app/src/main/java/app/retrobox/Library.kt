package app.retrobox

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Game(val uri: String, val name: String, val system: String) {
    val title: String get() = name.substringBeforeLast('.')
}

data class BiosFile(val uri: String, val name: String, val system: String)

/** Stores the game list and BIOS files (as document URIs) in SharedPreferences. */
class Library(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("library", Context.MODE_PRIVATE)

    fun games(): List<Game> {
        val out = ArrayList<Game>()
        try {
            val arr = JSONArray(prefs.getString(KEY_GAMES, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Game(o.getString("uri"), o.getString("name"), o.getString("system")))
            }
        } catch (e: Exception) {
            // Corrupt data: start with an empty library.
        }
        return out
    }

    private fun saveGames(list: List<Game>) {
        val arr = JSONArray()
        for (g in list) {
            arr.put(JSONObject().put("uri", g.uri).put("name", g.name).put("system", g.system))
        }
        prefs.edit().putString(KEY_GAMES, arr.toString()).apply()
    }

    /** Adds games, skipping any whose URI is already in the library. */
    fun addAll(newGames: List<Game>) {
        if (newGames.isEmpty()) return
        val current = ArrayList(games())
        val seen = HashSet<String>()
        for (g in current) seen.add(g.uri)
        for (g in newGames) {
            if (seen.add(g.uri)) current.add(g)
        }
        saveGames(current)
    }

    fun remove(uri: String) {
        saveGames(games().filter { it.uri != uri })
    }

    fun updateSystem(uri: String, system: String) {
        saveGames(games().map { if (it.uri == uri) it.copy(system = system) else it })
    }

    fun bios(): List<BiosFile> {
        val out = ArrayList<BiosFile>()
        try {
            val arr = JSONArray(prefs.getString(KEY_BIOS, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(BiosFile(o.getString("uri"), o.getString("name"), o.getString("system")))
            }
        } catch (e: Exception) {
            // Corrupt data: ignore.
        }
        return out
    }

    /** One BIOS file per system; a new one replaces the old one. */
    fun setBios(file: BiosFile) {
        val list = bios().filter { it.system != file.system } + file
        val arr = JSONArray()
        for (b in list) {
            arr.put(JSONObject().put("uri", b.uri).put("name", b.name).put("system", b.system))
        }
        prefs.edit().putString(KEY_BIOS, arr.toString()).apply()
    }

    private companion object {
        const val KEY_GAMES = "games"
        const val KEY_BIOS = "bios"
    }
}
