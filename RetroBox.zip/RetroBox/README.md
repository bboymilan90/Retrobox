# RetroBox

An Android app that plays retro games from one library: NES, SNES, Game Boy / Color, GBA, N64, DS, Genesis, Master System, Game Gear, Sega CD, Saturn, PlayStation, PC Engine, Atari (2600/7800/Lynx/Jaguar), Neo Geo Pocket, WonderSwan, 3DO, ColecoVision, Virtual Boy and arcade.

Emulation is done by [EmulatorJS](https://emulatorjs.org) running inside a WebView. You supply your own legally obtained ROMs; nothing is uploaded, files are read straight from your phone.

## Get the APK (no Android Studio needed)

1. Create a free GitHub account and a new **empty repository**.
2. Upload everything in this folder to it (drag and drop on the repo page, "uploading an existing file"). Make sure the `.github` folder is included.
3. Open the **Actions** tab. The "Build APK" run starts by itself (about 5 minutes).
4. When it is green, open the repository's **Releases** page and download `RetroBox.apk` on your phone, or download the `RetroBox-apk` artifact from the run.
5. Open the file on your phone and allow "Install unknown apps" when asked.

## Using it

- **Add games**: pick ROM files. **Add folder**: imports a whole folder, including subfolders.
- The system is detected from the file extension. For `.bin`, `.iso`, `.chd`, `.zip` you are asked which system they belong to. Long-press a game to change it or remove it.
- **BIOS**: PlayStation, Saturn, Sega CD, 3DO, DS, Lynx, Jaguar, arcade and some others need a BIOS file you provide. Pick the system, then the file.
- Inside a game, the emulator menu has save states, cheats, controls and settings. On-screen touch controls appear automatically; Bluetooth controllers work too.

## Notes

- Emulator cores are downloaded from the EmulatorJS CDN the first time you play each system, so internet is needed then (they are cached afterwards).
- Heavy systems (N64, DS, PS1, Saturn) run well only on a fairly recent phone.
- The app is signed with a debug key, which is fine for installing on your own phone.
